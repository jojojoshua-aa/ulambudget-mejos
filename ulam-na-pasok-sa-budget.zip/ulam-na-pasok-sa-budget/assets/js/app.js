document.addEventListener('DOMContentLoaded', function () {

    // Mobile menu
    var toggle = document.getElementById('menu-toggle');
    var menu = document.getElementById('menu');
    if (toggle && menu) {
        toggle.addEventListener('click', function () {
            var opening = menu.classList.contains('hidden');
            menu.classList.toggle('hidden', !opening);
            menu.classList.toggle('flex', opening);
            toggle.setAttribute('aria-expanded', opening ? 'true' : 'false');
        });
    }

    // Confirm before deleting (any form with data-confirm)
    document.querySelectorAll('form[data-confirm]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            if (!window.confirm(form.getAttribute('data-confirm'))) {
                e.preventDefault();
            }
        });
    });

    // Friendly client-side validation (server still validates everything)
    document.querySelectorAll('form[data-validate]').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            var firstBad = null;
            form.querySelectorAll('.js-error').forEach(function (n) { n.remove(); });

            form.querySelectorAll('[required]').forEach(function (input) {
                input.classList.remove('field-invalid');
                if (input.value.trim() === '') {
                    var label = form.querySelector('label[for="' + input.id + '"]');
                    var name = label ? label.textContent.replace('*', '').trim() : 'Ang field na ito';
                    var msg = document.createElement('p');
                    msg.className = 'field-error js-error';
                    msg.textContent = name + ' ay kailangang punan.';
                    input.insertAdjacentElement('afterend', msg);
                    input.classList.add('field-invalid');
                    if (!firstBad) firstBad = input;
                }
            });

            var pw = form.querySelector('#password');
            var pw2 = form.querySelector('#password_confirm');
            if (pw && pw2 && pw.value !== pw2.value && !firstBad) {
                var m = document.createElement('p');
                m.className = 'field-error js-error';
                m.textContent = 'Hindi magkapareho ang dalawang password.';
                pw2.insertAdjacentElement('afterend', m);
                pw2.classList.add('field-invalid');
                firstBad = pw2;
            }

            if (firstBad) {
                e.preventDefault();
                firstBad.focus();
            }
        });
    });

    // Show / hide password
    document.querySelectorAll('[data-toggle-password]').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var input = document.getElementById(btn.getAttribute('data-toggle-password'));
            if (!input) return;
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.textContent = show ? 'Itago' : 'Ipakita';
        });
    });

    // Auto-dismiss success messages
    document.querySelectorAll('.flash.border-dahon').forEach(function (n) {
        setTimeout(function () { n.remove(); }, 5000);
    });
});
