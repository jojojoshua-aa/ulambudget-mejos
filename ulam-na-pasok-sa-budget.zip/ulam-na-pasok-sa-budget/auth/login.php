<?php
require_once __DIR__ . '/../includes/functions.php';
require_guest();

$error = '';
$email = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $error = 'Nag-expire ang form. Subukan ulit.';
    } else {
        $email    = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password = (string) ($_POST['password'] ?? '');

        if ($email === '' || $password === '') {
            $error = 'Ilagay ang email at password.';
        } else {
            $stmt = db()->prepare('SELECT id, password_hash FROM users WHERE email = :email');
            $stmt->execute([':email' => $email]);
            $row = $stmt->fetch();

            if ($row && password_verify($password, $row['password_hash'])) {
                session_regenerate_id(true);           // prevent session fixation
                $_SESSION['user_id'] = (int) $row['id'];

                // Upgrade the hash if PHP's default algorithm/cost has changed.
                if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) {
                    $up = db()->prepare('UPDATE users SET password_hash = :h WHERE id = :id');
                    $up->execute([':h' => password_hash($password, PASSWORD_DEFAULT), ':id' => $row['id']]);
                }

                $next = pull_intended();
                if ($next !== null) {
                    header('Location: ' . $next);
                    exit;
                }
                redirect('dashboard.php');
            }
            // Same message for wrong email or wrong password (don't reveal which).
            $error = 'Mali ang email o password.';
        }
    }
}

$pageTitle = 'Login';
require __DIR__ . '/../includes/header.php';
?>
<section class="max-w-md mx-auto px-4 py-10">
    <h1 class="font-display font-extrabold text-3xl mb-1">Mag-login</h1>
    <p class="text-sabaw-soft mb-6">Balik sa kusina! Ilagay ang iyong account details.</p>

    <form method="post" data-validate novalidate class="bg-white rounded-xl border-2 border-sabaw p-6 space-y-4 shadow-[6px_6px_0_#3A1F0F]">
        <?= csrf_field() ?>
        <?php if ($error): ?>
            <div role="alert" class="rounded-lg bg-red-50 border-l-4 border-red-600 text-red-900 px-3 py-2"><?= e($error) ?></div>
        <?php endif; ?>

        <div>
            <label for="email" class="block font-bold mb-1">Email *</label>
            <input id="email" name="email" type="email" required autocomplete="email" class="field" value="<?= e($email) ?>">
        </div>

        <div>
            <label for="login_password" class="block font-bold mb-1">Password *</label>
            <div class="flex gap-2">
                <input id="login_password" name="password" type="password" required autocomplete="current-password" class="field">
                <button type="button" data-toggle-password="login_password" class="shrink-0 rounded-lg border-2 border-sabaw px-3 font-bold text-sm">Ipakita</button>
            </div>
        </div>

        <button type="submit" class="w-full rounded-lg bg-atsuete hover:bg-atsuete-dark text-white font-bold py-3 transition-colors">Login</button>
    </form>

    <p class="mt-5 text-center">Wala pang account? <a class="font-bold underline" href="<?= e(url('auth/register.php')) ?>">Mag-register</a></p>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
