<?php
require_once __DIR__ . '/../includes/functions.php';

// Logout is POST-only with a CSRF token so other sites can't log users out.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && csrf_valid()) {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();

    session_id(session_create_id());       // brand-new session id
    session_start();                       // only to carry the goodbye message
    flash('success', 'Naka-logout ka na. Hanggang sa susunod na luto!');
}
redirect('index.php');
