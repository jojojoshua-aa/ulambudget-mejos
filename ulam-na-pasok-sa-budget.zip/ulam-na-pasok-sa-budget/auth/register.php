<?php
require_once __DIR__ . '/../includes/functions.php';
require_guest();

$errors = [];
$old = ['full_name' => '', 'email' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $errors['form'] = 'Nag-expire ang form. Subukan ulit.';
    } else {
        $old['full_name'] = trim((string) ($_POST['full_name'] ?? ''));
        $old['email']     = strtolower(trim((string) ($_POST['email'] ?? '')));
        $password         = (string) ($_POST['password'] ?? '');
        $confirm          = (string) ($_POST['password_confirm'] ?? '');

        if ($old['full_name'] === '') {
            $errors['full_name'] = 'Ilagay ang buong pangalan.';
        } elseif (mb_strlen($old['full_name']) > 100) {
            $errors['full_name'] = 'Masyadong mahaba ang pangalan (max 100).';
        }

        if ($old['email'] === '') {
            $errors['email'] = 'Ilagay ang email.';
        } elseif (!filter_var($old['email'], FILTER_VALIDATE_EMAIL) || mb_strlen($old['email']) > 150) {
            $errors['email'] = 'Hindi valid ang email address.';
        }

        if (strlen($password) < 8) {
            $errors['password'] = 'Ang password ay dapat hindi bababa sa 8 character.';
        }
        if ($password !== $confirm) {
            $errors['password_confirm'] = 'Hindi magkapareho ang dalawang password.';
        }

        if (!$errors) {
            $check = db()->prepare('SELECT id FROM users WHERE email = :email');
            $check->execute([':email' => $old['email']]);
            if ($check->fetch()) {
                $errors['email'] = 'May account na gamit ang email na ito. Subukang mag-login.';
            }
        }

        if (!$errors) {
            // Public registration always creates a regular user, never an admin.
            $stmt = db()->prepare(
                'INSERT INTO users (full_name, email, password_hash, role) VALUES (:n, :e, :p, \'user\')'
            );
            $stmt->execute([
                ':n' => $old['full_name'],
                ':e' => $old['email'],
                ':p' => password_hash($password, PASSWORD_DEFAULT),
            ]);
            flash('success', 'Naka-register ka na! Mag-login para magsimula.');
            redirect('auth/login.php');
        }
    }
}

$pageTitle = 'Mag-register';
require __DIR__ . '/../includes/header.php';
?>
<section class="max-w-md mx-auto px-4 py-10">
    <h1 class="font-display font-extrabold text-3xl mb-1">Gumawa ng account</h1>
    <p class="text-sabaw-soft mb-6">Libre. Makakapag-save ka ng sarili mong budget recipes.</p>

    <form method="post" data-validate novalidate class="bg-white rounded-xl border-2 border-sabaw p-6 space-y-4 shadow-[6px_6px_0_#3A1F0F]">
        <?= csrf_field() ?>
        <?php if (!empty($errors['form'])): ?>
            <div role="alert" class="rounded-lg bg-red-50 border-l-4 border-red-600 text-red-900 px-3 py-2"><?= e($errors['form']) ?></div>
        <?php endif; ?>

        <div>
            <label for="full_name" class="block font-bold mb-1">Buong pangalan *</label>
            <input id="full_name" name="full_name" type="text" required maxlength="100" autocomplete="name"
                   class="field <?= isset($errors['full_name']) ? 'field-invalid' : '' ?>" value="<?= e($old['full_name']) ?>">
            <?php if (isset($errors['full_name'])): ?><p class="field-error"><?= e($errors['full_name']) ?></p><?php endif; ?>
        </div>

        <div>
            <label for="email" class="block font-bold mb-1">Email *</label>
            <input id="email" name="email" type="email" required maxlength="150" autocomplete="email"
                   class="field <?= isset($errors['email']) ? 'field-invalid' : '' ?>" value="<?= e($old['email']) ?>">
            <?php if (isset($errors['email'])): ?><p class="field-error"><?= e($errors['email']) ?></p><?php endif; ?>
        </div>

        <div>
            <label for="password" class="block font-bold mb-1">Password * <span class="font-normal text-sm text-sabaw-soft">(8+ characters)</span></label>
            <input id="password" name="password" type="password" required autocomplete="new-password"
                   class="field <?= isset($errors['password']) ? 'field-invalid' : '' ?>">
            <?php if (isset($errors['password'])): ?><p class="field-error"><?= e($errors['password']) ?></p><?php endif; ?>
        </div>

        <div>
            <label for="password_confirm" class="block font-bold mb-1">Ulitin ang password *</label>
            <input id="password_confirm" name="password_confirm" type="password" required autocomplete="new-password"
                   class="field <?= isset($errors['password_confirm']) ? 'field-invalid' : '' ?>">
            <?php if (isset($errors['password_confirm'])): ?><p class="field-error"><?= e($errors['password_confirm']) ?></p><?php endif; ?>
        </div>

        <button type="submit" class="w-full rounded-lg bg-atsuete hover:bg-atsuete-dark text-white font-bold py-3 transition-colors">Mag-register</button>
    </form>

    <p class="mt-5 text-center">May account na? <a class="font-bold underline" href="<?= e(url('auth/login.php')) ?>">Mag-login</a></p>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
