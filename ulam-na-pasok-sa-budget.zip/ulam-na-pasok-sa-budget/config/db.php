<?php
// Database connection (PDO). Default XAMPP credentials: root / no password.
const DB_HOST = 'localhost';
const DB_NAME = 'ulam_budget';
const DB_USER = 'root';
const DB_PASS = '';

function db(): PDO
{
    static $pdo = null;
    if ($pdo === null) {
        try {
            $pdo = new PDO(
                'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
                DB_USER,
                DB_PASS,
                [
                    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES   => false, // real prepared statements
                ]
            );
        } catch (PDOException $e) {
            http_response_code(500);
            exit('<h1>Hindi maka-connect sa database.</h1>'
               . '<p>Siguraduhing tumatakbo ang MySQL sa XAMPP at na-import na ang <code>database.sql</code>.</p>');
        }
    }
    return $pdo;
}
