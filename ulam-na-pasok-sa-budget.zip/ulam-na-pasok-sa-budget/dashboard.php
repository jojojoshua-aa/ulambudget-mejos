<?php
require_once __DIR__ . '/includes/functions.php';
$user = require_login();

// ---- Filters (all optional) ----
$q        = trim((string) ($_GET['q'] ?? ''));
$category = in_array($_GET['category'] ?? '', CATEGORIES, true) ? $_GET['category'] : '';
$budget   = in_array($_GET['budget'] ?? '', BUDGETS, true) ? $_GET['budget'] : '';
$scope    = ($_GET['scope'] ?? '') === 'mine' ? 'mine' : 'all';
$page     = max(1, (int) ($_GET['page'] ?? 1));
$perPage  = 9;

$where  = [];
$params = [];

// Regular users see public (admin) recipes plus their own. Admins see everything.
if (!is_admin()) {
    $where[]          = '(r.is_public = 1 OR r.user_id = :uid)';
    $params[':uid']   = $user['id'];
}
if ($scope === 'mine') {
    $where[]          = 'r.user_id = :mine';
    $params[':mine']  = $user['id'];
}
if ($q !== '') {
    $where[]          = '(r.dish_name LIKE :q1 OR r.ingredients LIKE :q2)';
    $params[':q1']    = '%' . $q . '%';
    $params[':q2']    = '%' . $q . '%';
}
if ($category !== '') {
    $where[]          = 'r.category = :cat';
    $params[':cat']   = $category;
}
if ($budget !== '') {
    $where[]          = 'r.budget = :bud';
    $params[':bud']   = $budget;
}
$whereSql = $where ? 'WHERE ' . implode(' AND ', $where) : '';

$count = db()->prepare("SELECT COUNT(*) FROM recipes r $whereSql");
$count->execute($params);
$total = (int) $count->fetchColumn();
$pages = max(1, (int) ceil($total / $perPage));
$page  = min($page, $pages);

$sql  = "SELECT r.*, u.full_name AS author
         FROM recipes r JOIN users u ON u.id = r.user_id
         $whereSql ORDER BY r.created_at DESC, r.id DESC LIMIT :lim OFFSET :off";
$stmt = db()->prepare($sql);
foreach ($params as $k => $v) {
    $stmt->bindValue($k, $v);
}
$stmt->bindValue(':lim', $perPage, PDO::PARAM_INT);
$stmt->bindValue(':off', ($page - 1) * $perPage, PDO::PARAM_INT);
$stmt->execute();
$recipes = $stmt->fetchAll();

$mine = db()->prepare('SELECT COUNT(*) FROM recipes WHERE user_id = :id');
$mine->execute([':id' => $user['id']]);
$myCount = (int) $mine->fetchColumn();

// Keep filters in pagination links.
$qs = fn(array $extra = []) => '?' . http_build_query(array_filter(
    array_merge(['q' => $q, 'category' => $category, 'budget' => $budget, 'scope' => $scope === 'mine' ? 'mine' : ''], $extra),
    fn($v) => $v !== '' && $v !== null
));

$pageTitle = 'Mga Recipe';
require __DIR__ . '/includes/header.php';
?>
<section class="max-w-6xl mx-auto px-4 py-8">
    <div class="flex flex-wrap items-end justify-between gap-4">
        <div>
            <h1 class="font-display font-extrabold text-3xl">Kumusta, <?= e(explode(' ', $user['full_name'])[0]) ?>!</h1>
            <p class="text-sabaw-soft">
                <?php if (is_admin()): ?>
                    Admin ka: kaya mong i-edit at i-delete ang kahit anong recipe.
                <?php else: ?>
                    May <?= $myCount ?> kang sariling recipe. Ang mga recipe ng admin ay pwede mong basahin.
                <?php endif; ?>
            </p>
        </div>
        <a href="<?= e(url('recipes/create.php')) ?>" class="rounded-lg bg-atsuete hover:bg-atsuete-dark text-white font-bold px-5 py-2.5 transition-colors">Magdagdag ng Recipe</a>
    </div>

    <!-- Filters -->
    <form method="get" class="mt-6 bg-white border-2 border-sabaw rounded-xl p-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-5 items-end">
        <div class="lg:col-span-2">
            <label for="q" class="block text-sm font-bold mb-1">Hanapin</label>
            <input id="q" name="q" type="search" placeholder="Pangalan ng ulam o sangkap" class="field" value="<?= e($q) ?>">
        </div>
        <div>
            <label for="category" class="block text-sm font-bold mb-1">Kategorya</label>
            <select id="category" name="category" class="field">
                <option value="">Lahat</option>
                <?php foreach (CATEGORIES as $c): ?>
                    <option value="<?= e($c) ?>" <?= $category === $c ? 'selected' : '' ?>><?= e($c) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="budget" class="block text-sm font-bold mb-1">Budget</label>
            <select id="budget" name="budget" class="field">
                <option value="">Lahat</option>
                <?php foreach (BUDGETS as $b): ?>
                    <option value="<?= e($b) ?>" <?= $budget === $b ? 'selected' : '' ?>><?= e($b) ?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div>
            <label for="scope" class="block text-sm font-bold mb-1">Ipakita</label>
            <select id="scope" name="scope" class="field">
                <option value="all" <?= $scope === 'all' ? 'selected' : '' ?>><?= is_admin() ? 'Lahat ng recipe' : 'Lahat ng pwede kong makita' ?></option>
                <option value="mine" <?= $scope === 'mine' ? 'selected' : '' ?>>Mga recipe ko lang</option>
            </select>
        </div>
        <div class="sm:col-span-2 lg:col-span-5 flex gap-3">
            <button type="submit" class="rounded-lg bg-sabaw text-kalamansi font-bold px-5 py-2 hover:bg-atsuete hover:text-white transition-colors">I-apply</button>
            <a href="<?= e(url('dashboard.php')) ?>" class="rounded-lg border-2 border-sabaw font-bold px-5 py-2">I-clear</a>
        </div>
    </form>

    <p class="mt-6 text-sm text-sabaw-soft"><?= $total ?> recipe ang nahanap</p>

    <?php if (!$recipes): ?>
        <div class="mt-4 bg-white border-2 border-dashed border-sabaw/40 rounded-xl p-10 text-center">
            <p class="font-display font-bold text-xl">Wala pang recipe dito.</p>
            <p class="text-sabaw-soft mt-1">Subukang baguhin ang filter, o idagdag ang una mong recipe.</p>
            <a href="<?= e(url('recipes/create.php')) ?>" class="inline-block mt-4 rounded-lg bg-atsuete text-white font-bold px-5 py-2.5">Magdagdag ng Recipe</a>
        </div>
    <?php else: ?>
        <div class="mt-4 grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <?php foreach ($recipes as $r):
                $st = category_style($r['category']); ?>
                <article class="bg-white border-2 border-sabaw rounded-xl flex flex-col">
                    <div class="p-5 flex-1">
                        <div class="flex items-center justify-between gap-2">
                            <span class="rounded-full px-3 py-1 text-sm font-bold <?= $st['badge'] ?>"><?= $st['emoji'] ?> <?= e($r['category']) ?></span>
                            <?php if ((int) $r['is_public'] === 0): ?>
                                <span class="text-xs font-bold rounded-full border border-sabaw px-2 py-0.5">Pribado</span>
                            <?php endif; ?>
                        </div>
                        <h2 class="font-display font-extrabold text-xl mt-3 leading-snug">
                            <a class="hover:underline" href="<?= e(url('recipes/view.php?id=' . (int) $r['id'])) ?>"><?= e($r['dish_name']) ?></a>
                        </h2>
                        <dl class="mt-3 text-sm space-y-1">
                            <div class="flex justify-between"><dt class="text-sabaw-soft">Budget</dt><dd class="font-bold text-atsuete"><?= e($r['budget']) ?></dd></div>
                            <div class="flex justify-between"><dt class="text-sabaw-soft">Paghahanda</dt><dd class="font-bold"><?= (int) $r['prep_time'] ?> min</dd></div>
                            <div class="flex justify-between"><dt class="text-sabaw-soft">May-akda</dt><dd><?= e($r['author']) ?></dd></div>
                        </dl>
                    </div>
                    <div class="border-t-2 border-sabaw/10 p-3 flex items-center gap-2">
                        <a href="<?= e(url('recipes/view.php?id=' . (int) $r['id'])) ?>" class="rounded-lg border-2 border-sabaw px-3 py-1.5 text-sm font-bold hover:bg-kalamansi">Tingnan</a>
                        <?php if (can_manage_recipe($r)): ?>
                            <a href="<?= e(url('recipes/edit.php?id=' . (int) $r['id'])) ?>" class="rounded-lg border-2 border-sabaw px-3 py-1.5 text-sm font-bold hover:bg-kalamansi">I-edit</a>
                            <form method="post" action="<?= e(url('recipes/delete.php')) ?>" class="ml-auto"
                                  data-confirm="Sigurado ka bang buburahin ang &quot;<?= e($r['dish_name']) ?>&quot;? Hindi na ito maibabalik.">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $r['id'] ?>">
                                <button type="submit" class="rounded-lg bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 text-sm font-bold">I-delete</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>

        <?php if ($pages > 1): ?>
        <nav class="mt-8 flex flex-wrap gap-2 justify-center" aria-label="Pagination">
            <?php for ($i = 1; $i <= $pages; $i++): ?>
                <a href="<?= e($qs(['page' => $i === 1 ? '' : $i])) ?>"
                   class="rounded-lg border-2 border-sabaw px-3.5 py-1.5 font-bold <?= $i === $page ? 'bg-sabaw text-kalamansi' : 'bg-white hover:bg-kalamansi' ?>"
                   <?= $i === $page ? 'aria-current="page"' : '' ?>><?= $i ?></a>
            <?php endfor; ?>
        </nav>
        <?php endif; ?>
    <?php endif; ?>
</section>
<?php require __DIR__ . '/includes/footer.php'; ?>
