</main>

<footer class="bg-sabaw text-kalamansi-light mt-12">
    <div class="max-w-6xl mx-auto px-4 py-6 text-sm flex flex-col sm:flex-row gap-2 justify-between">
        <p class="font-display font-bold">Ulam na Pasok sa Budget</p>
        <p>Proyekto sa unibersidad &copy; <?= date('Y') ?>. Mga recipe para sa estudyante at sa bulsang nagtitipid.</p>
    </div>
</footer>

<script src="<?= e(url('assets/js/app.js')) ?>"></script>
</body>
</html>
