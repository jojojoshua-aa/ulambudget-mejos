<?php
declare(strict_types=1);

if (session_status() === PHP_SESSION_NONE) {
    session_set_cookie_params(['httponly' => true, 'samesite' => 'Lax']);
    session_start();
}

require_once __DIR__ . '/../config/db.php';

const CATEGORIES = ['Almusal', 'Tanghalian', 'Hapunan'];
const BUDGETS    = ['Under ₱50', 'Under ₱100', 'Under ₱150', 'Under ₱200', '₱200 pataas'];

/* ---------- URLs & output ---------- */

// Works whatever folder name the project is placed in under htdocs.
function detect_base_url(): string
{
    $root = str_replace('\\', '/', (string) realpath($_SERVER['DOCUMENT_ROOT'] ?? ''));
    $proj = str_replace('\\', '/', (string) realpath(__DIR__ . '/..'));
    if ($root !== '' && stripos($proj, $root) === 0) {
        return rtrim(substr($proj, strlen($root)), '/');
    }
    return '';
}
define('BASE_URL', detect_base_url());

function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

function e($value): string
{
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

function redirect(string $path): void
{
    header('Location: ' . url($path));
    exit;
}

/* ---------- Flash messages ---------- */

function flash(string $type, string $message): void
{
    $_SESSION['flash'][] = ['type' => $type, 'msg' => $message];
}

function get_flashes(): array
{
    $f = $_SESSION['flash'] ?? [];
    unset($_SESSION['flash']);
    return $f;
}

/* ---------- CSRF ---------- */

function csrf_token(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="csrf" value="' . e(csrf_token()) . '">';
}

function csrf_valid(): bool
{
    $t = $_POST['csrf'] ?? '';
    return is_string($t) && isset($_SESSION['csrf']) && hash_equals($_SESSION['csrf'], $t);
}

/* ---------- Auth ---------- */

// Re-reads the user each request so a deleted account or changed role takes effect immediately.
function current_user(): ?array
{
    static $user = false;
    if ($user !== false) {
        return $user;
    }
    $user = null;
    if (!empty($_SESSION['user_id'])) {
        $stmt = db()->prepare('SELECT id, full_name, email, role FROM users WHERE id = :id');
        $stmt->execute([':id' => $_SESSION['user_id']]);
        $row = $stmt->fetch();
        if ($row) {
            $user = $row;
        } else {
            unset($_SESSION['user_id']);
        }
    }
    return $user;
}

function is_admin(): bool
{
    $u = current_user();
    return $u !== null && $u['role'] === 'admin';
}

function require_login(): array
{
    $u = current_user();
    if ($u === null) {
        if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'GET') {
            $_SESSION['intended'] = $_SERVER['REQUEST_URI'] ?? '';
        }
        flash('warning', 'Mag-login muna para ma-access ang page na ito.');
        redirect('auth/login.php');
    }
    return $u;
}

function require_guest(): void
{
    if (current_user() !== null) {
        redirect('dashboard.php');
    }
}

// Returns the page the visitor originally wanted, only if it is inside this app.
function pull_intended(): ?string
{
    $t = $_SESSION['intended'] ?? null;
    unset($_SESSION['intended']);
    if (is_string($t) && strpos($t, BASE_URL . '/') === 0
        && strpos($t, '//') === false && strpos($t, '\\') === false
        && !preg_match('/[\r\n]/', $t)) {
        return $t;
    }
    return null;
}

/* ---------- Recipe permissions ---------- */

function can_view_recipe(array $r): bool
{
    $u = current_user();
    return $u !== null && ($u['role'] === 'admin' || (int) $r['is_public'] === 1 || (int) $r['user_id'] === (int) $u['id']);
}

function can_manage_recipe(array $r): bool
{
    $u = current_user();
    return $u !== null && ($u['role'] === 'admin' || (int) $r['user_id'] === (int) $u['id']);
}

function find_recipe(int $id): ?array
{
    $stmt = db()->prepare(
        'SELECT r.*, u.full_name AS author FROM recipes r JOIN users u ON u.id = r.user_id WHERE r.id = :id'
    );
    $stmt->execute([':id' => $id]);
    return $stmt->fetch() ?: null;
}

/* ---------- Recipe validation ---------- */

function normalize_lines($text): string
{
    $lines = preg_split('/\R/', (string) $text) ?: [];
    $lines = array_filter(array_map('trim', $lines), fn($l) => $l !== '');
    return implode("\n", $lines);
}

function lines_to_array(string $text): array
{
    return array_values(array_filter(array_map('trim', preg_split('/\R/', $text) ?: []), fn($l) => $l !== ''));
}

// Returns [cleanValues, errors]
function validate_recipe(array $in): array
{
    $v = [
        'dish_name'    => trim((string) ($in['dish_name'] ?? '')),
        'category'     => (string) ($in['category'] ?? ''),
        'budget'       => (string) ($in['budget'] ?? ''),
        'prep_time'    => trim((string) ($in['prep_time'] ?? '')),
        'ingredients'  => normalize_lines($in['ingredients'] ?? ''),
        'instructions' => normalize_lines($in['instructions'] ?? ''),
    ];
    $err = [];

    if ($v['dish_name'] === '') {
        $err['dish_name'] = 'Ilagay ang pangalan ng ulam.';
    } elseif (mb_strlen($v['dish_name']) < 3 || mb_strlen($v['dish_name']) > 120) {
        $err['dish_name'] = 'Ang pangalan ay dapat 3 hanggang 120 na character.';
    }

    if (!in_array($v['category'], CATEGORIES, true)) {
        $err['category'] = 'Pumili ng Almusal, Tanghalian, o Hapunan.';
    }

    if (!in_array($v['budget'], BUDGETS, true)) {
        $err['budget'] = 'Pumili ng tinatayang budget.';
    }

    if ($v['prep_time'] === '') {
        $err['prep_time'] = 'Ilagay kung ilang minuto ang paghahanda.';
    } elseif (!ctype_digit($v['prep_time']) || (int) $v['prep_time'] < 1 || (int) $v['prep_time'] > 600) {
        $err['prep_time'] = 'Ang oras ay dapat buong numero mula 1 hanggang 600 minuto.';
    }

    if ($v['ingredients'] === '') {
        $err['ingredients'] = 'Maglista ng kahit isang sangkap (isang sangkap kada linya).';
    } elseif (mb_strlen($v['ingredients']) > 5000) {
        $err['ingredients'] = 'Masyadong mahaba ang listahan ng sangkap (max 5,000 character).';
    }

    if ($v['instructions'] === '') {
        $err['instructions'] = 'Isulat ang mga hakbang sa pagluluto (isang hakbang kada linya).';
    } elseif (mb_strlen($v['instructions']) > 8000) {
        $err['instructions'] = 'Masyadong mahaba ang mga hakbang (max 8,000 character).';
    }

    return [$v, $err];
}

/* ---------- Small view helpers ---------- */

function category_style(string $cat): array
{
    return match ($cat) {
        'Almusal'    => ['emoji' => '🍳', 'badge' => 'bg-kalamansi text-sabaw'],
        'Tanghalian' => ['emoji' => '🍚', 'badge' => 'bg-atsuete text-white'],
        default      => ['emoji' => '🍲', 'badge' => 'bg-sabaw text-kalamansi'],
    };
}
