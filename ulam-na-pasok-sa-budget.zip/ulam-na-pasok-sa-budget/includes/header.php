<?php
// Expects: $pageTitle (string). Include after includes/functions.php.
$user    = current_user();
$flashes = get_flashes();
$title   = isset($pageTitle) ? $pageTitle . ' – Ulam na Pasok sa Budget' : 'Ulam na Pasok sa Budget';
?>
<!DOCTYPE html>
<html lang="fil">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($title) ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,600;800&family=DM+Sans:wght@400;500;700&display=swap" rel="stylesheet">
    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    colors: {
                        kalamansi: { DEFAULT: '#FFC83D', light: '#FFF1C2', soft: '#FFF8E1' },
                        atsuete:   { DEFAULT: '#E8590C', dark: '#B8440A' },
                        sabaw:     { DEFAULT: '#3A1F0F', soft: '#6B4A35' },
                        dahon:     '#2F7D32'
                    },
                    fontFamily: {
                        display: ['"Bricolage Grotesque"', 'system-ui', 'sans-serif'],
                        sans: ['"DM Sans"', 'system-ui', 'sans-serif']
                    }
                }
            }
        };
    </script>
    <link rel="stylesheet" href="<?= e(url('assets/css/style.css')) ?>">
</head>
<body class="bg-kalamansi-soft text-sabaw font-sans antialiased min-h-screen flex flex-col">

<header class="bg-kalamansi border-b-2 border-sabaw/10 sticky top-0 z-30">
    <nav class="max-w-6xl mx-auto px-4 py-3 flex items-center justify-between gap-4" aria-label="Pangunahing menu">
        <a href="<?= e(url('index.php')) ?>" class="flex items-center gap-2 font-display font-extrabold text-lg sm:text-xl leading-tight">
            <span class="inline-flex h-9 w-9 items-center justify-center rounded-full bg-atsuete text-white text-lg" aria-hidden="true">₱</span>
            <span>Ulam na Pasok<br class="sm:hidden"> sa Budget</span>
        </a>

        <button type="button" id="menu-toggle" class="md:hidden rounded-lg border-2 border-sabaw px-3 py-1.5 font-bold"
                aria-expanded="false" aria-controls="menu">Menu</button>

        <div id="menu" class="hidden md:flex w-full md:w-auto flex-col md:flex-row md:items-center gap-2 md:gap-5 absolute md:static left-0 top-full bg-kalamansi md:bg-transparent px-4 py-4 md:p-0 border-b-2 md:border-0 border-sabaw/10">
            <a class="nav-link" href="<?= e(url('index.php')) ?>">Home</a>
            <?php if ($user): ?>
                <a class="nav-link" href="<?= e(url('dashboard.php')) ?>">Mga Recipe</a>
                <a class="nav-link" href="<?= e(url('recipes/create.php')) ?>">Magdagdag ng Recipe</a>
                <span class="text-sm md:ml-2">
                    <?= e($user['full_name']) ?>
                    <span class="ml-1 rounded-full px-2 py-0.5 text-xs font-bold <?= $user['role'] === 'admin' ? 'bg-sabaw text-kalamansi' : 'bg-white text-sabaw' ?>">
                        <?= $user['role'] === 'admin' ? 'Admin' : 'User' ?>
                    </span>
                </span>
                <form method="post" action="<?= e(url('auth/logout.php')) ?>">
                    <?= csrf_field() ?>
                    <button type="submit" class="rounded-lg border-2 border-sabaw px-4 py-1.5 font-bold hover:bg-sabaw hover:text-kalamansi transition-colors">Logout</button>
                </form>
            <?php else: ?>
                <a class="nav-link" href="<?= e(url('index.php#kategorya')) ?>">Kategorya</a>
                <a class="nav-link" href="<?= e(url('index.php#budget-hacks')) ?>">Budget Hacks</a>
                <a class="nav-link" href="<?= e(url('auth/register.php')) ?>">Mag-register</a>
                <a class="rounded-lg bg-sabaw text-kalamansi px-4 py-1.5 font-bold hover:bg-atsuete hover:text-white transition-colors text-center"
                   href="<?= e(url('auth/login.php')) ?>">Login</a>
            <?php endif; ?>
        </div>
    </nav>
</header>

<?php if ($flashes): ?>
<div class="max-w-6xl mx-auto w-full px-4 pt-4 space-y-2" id="flash-area">
    <?php foreach ($flashes as $f):
        $cls = match ($f['type']) {
            'success' => 'bg-green-50 border-dahon text-green-900',
            'error'   => 'bg-red-50 border-red-600 text-red-900',
            default   => 'bg-kalamansi-light border-atsuete text-sabaw',
        }; ?>
        <div role="status" class="flash rounded-lg border-l-4 px-4 py-3 <?= $cls ?>"><?= e($f['msg']) ?></div>
    <?php endforeach; ?>
</div>
<?php endif; ?>

<main class="flex-1">
