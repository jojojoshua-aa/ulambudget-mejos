<?php
// Shared by create.php and edit.php.
// Expects: $values (array), $errors (array), $submitLabel (string), $cancelUrl (string)
$fe = fn(string $k) => isset($errors[$k]) ? '<p class="field-error">' . e($errors[$k]) . '</p>' : '';
$inv = fn(string $k) => isset($errors[$k]) ? 'field-invalid' : '';
?>
<form method="post" data-validate novalidate class="bg-white border-2 border-sabaw rounded-xl p-6 space-y-5 shadow-[6px_6px_0_#3A1F0F]">
    <?= csrf_field() ?>

    <?php if ($errors): ?>
        <div role="alert" class="rounded-lg bg-red-50 border-l-4 border-red-600 text-red-900 px-4 py-3">
            <p class="font-bold">May kailangang ayusin bago i-save:</p>
            <ul class="list-disc ml-5 mt-1 text-sm">
                <?php foreach ($errors as $msg): ?><li><?= e($msg) ?></li><?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>

    <div>
        <label for="dish_name" class="block font-bold mb-1">Pangalan ng ulam *</label>
        <input id="dish_name" name="dish_name" type="text" required maxlength="120" class="field <?= $inv('dish_name') ?>"
               placeholder="hal. Ginisang Ampalaya na may Itlog" value="<?= e($values['dish_name']) ?>">
        <?= $fe('dish_name') ?>
    </div>

    <div class="grid gap-5 sm:grid-cols-3">
        <div>
            <label for="category" class="block font-bold mb-1">Kategorya *</label>
            <select id="category" name="category" required class="field <?= $inv('category') ?>">
                <option value="">Pumili…</option>
                <?php foreach (CATEGORIES as $c): ?>
                    <option value="<?= e($c) ?>" <?= $values['category'] === $c ? 'selected' : '' ?>><?= e($c) ?></option>
                <?php endforeach; ?>
            </select>
            <?= $fe('category') ?>
        </div>
        <div>
            <label for="budget" class="block font-bold mb-1">Tinatayang budget *</label>
            <select id="budget" name="budget" required class="field <?= $inv('budget') ?>">
                <option value="">Pumili…</option>
                <?php foreach (BUDGETS as $b): ?>
                    <option value="<?= e($b) ?>" <?= $values['budget'] === $b ? 'selected' : '' ?>><?= e($b) ?></option>
                <?php endforeach; ?>
            </select>
            <?= $fe('budget') ?>
        </div>
        <div>
            <label for="prep_time" class="block font-bold mb-1">Oras ng paghahanda (minuto) *</label>
            <input id="prep_time" name="prep_time" type="number" min="1" max="600" required class="field <?= $inv('prep_time') ?>"
                   value="<?= e($values['prep_time']) ?>">
            <?= $fe('prep_time') ?>
        </div>
    </div>

    <div>
        <label for="ingredients" class="block font-bold mb-1">Mga sangkap * <span class="font-normal text-sm text-sabaw-soft">(isang sangkap kada linya)</span></label>
        <textarea id="ingredients" name="ingredients" rows="6" required class="field <?= $inv('ingredients') ?>"
                  placeholder="Itlog (2 piraso)&#10;Kamatis (1 piraso)&#10;Bawang (3 butil)"><?= e($values['ingredients']) ?></textarea>
        <?= $fe('ingredients') ?>
    </div>

    <div>
        <label for="instructions" class="block font-bold mb-1">Mga hakbang sa pagluluto * <span class="font-normal text-sm text-sabaw-soft">(isang hakbang kada linya)</span></label>
        <textarea id="instructions" name="instructions" rows="8" required class="field <?= $inv('instructions') ?>"
                  placeholder="Igisa ang bawang at kamatis.&#10;Ilagay ang itlog at haluin."><?= e($values['instructions']) ?></textarea>
        <?= $fe('instructions') ?>
    </div>

    <div class="flex flex-wrap gap-3">
        <button type="submit" class="rounded-lg bg-atsuete hover:bg-atsuete-dark text-white font-bold px-6 py-2.5 transition-colors"><?= e($submitLabel) ?></button>
        <a href="<?= e($cancelUrl) ?>" class="rounded-lg border-2 border-sabaw font-bold px-6 py-2.5">Kanselahin</a>
    </div>
</form>
