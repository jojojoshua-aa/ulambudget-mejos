<?php
require_once __DIR__ . '/includes/functions.php';

$user = current_user();
$ctaUrl  = $user ? url('dashboard.php') : url('auth/login.php');
$ctaText = $user ? 'Pumunta sa mga Recipe' : 'Login to Manage Recipes';

$categories = [
    ['name' => 'Almusal',    'emoji' => '🍳', 'bg' => 'bg-kalamansi',  'text' => 'text-sabaw',
     'desc' => 'Sinangag, itlog, tuyo, champorado. Pampagising na hindi uubos sa baon.'],
    ['name' => 'Tanghalian', 'emoji' => '🍚', 'bg' => 'bg-atsuete',    'text' => 'text-white',
     'desc' => 'Ulam na pang-kanin: monggo, pritong isda, at gulay na tipid pero busog.'],
    ['name' => 'Hapunan',    'emoji' => '🍲', 'bg' => 'bg-sabaw',      'text' => 'text-kalamansi-light',
     'desc' => 'Mainit na sabaw at ginisa para sa pagod na gabi pagkatapos ng klase.'],
];

$swaps = [
    ['Buong ulo ng bawang at sibuyas', 'Bumili ng tingi sa sari-sari store, kung ilan lang ang kailangan'],
    ['Sariwang gata', 'Gata sa sachet o lata, mas tipid kapag kaunti lang ang lulutuin'],
    ['Baboy o manok bilang sangkap', 'Tokwa, itlog, sardinas, o dilis na mas mura at may protina pa rin'],
    ['Sariwang sampalok para sa sinigang', 'Sinigang mix sa sachet'],
    ['Malaking bote ng toyo, suka, at patis', 'Sachet o maliit na bote na sapat lang sa isang linggo'],
    ['Pampalasa mula sa mamahaling brand', 'Asin, paminta, at kalamansi ang pinakamurang pampasarap'],
];

$tips = [
    'Magsaing nang marami at i-freeze ang sobrang kanin. Gagawin mong sinangag bukas ng umaga.',
    'Gumawa ng isang batch ng ginisa (bawang, sibuyas, kamatis) at hatiin para sa susunod na dalawang ulam.',
    'Bumili ng isang klaseng gulay at gamitin sa dalawa o tatlong ulam, gaya ng kalabasa sa tinola at ginataan.',
    'Magplano ng menu para sa linggo bago mamalengke para walang masayang na sangkap.',
    'Lutuin nang sobra ang hapunan para ulam na rin ito sa tanghalian kinabukasan.',
];

$pageTitle = 'Madali, Masarap, at Swak sa Budget';
require __DIR__ . '/includes/header.php';
?>

<!-- Hero -->
<section class="bg-kalamansi border-b-2 border-sabaw/10">
    <div class="max-w-6xl mx-auto px-4 py-12 md:py-20 grid md:grid-cols-2 gap-10 items-center">
        <div>
            <h1 class="font-display font-extrabold text-4xl sm:text-5xl lg:text-6xl leading-[1.05]">
                Madali, Masarap, at Swak sa Budget!
            </h1>
            <p class="mt-5 text-lg max-w-lg">
                Isang gabay sa mga Pinoy na ulam para sa estudyante at sa sinumang nagtitipid.
                I-save ang sarili mong mga recipe at planuhin ang pagkain mo sa buong linggo.
            </p>
            <div class="mt-8 flex flex-wrap gap-3">
                <a href="<?= e($ctaUrl) ?>" class="rounded-lg bg-sabaw text-kalamansi font-bold px-6 py-3 hover:bg-atsuete hover:text-white transition-colors">
                    <?= e($ctaText) ?>
                </a>
                <?php if (!$user): ?>
                <a href="<?= e(url('auth/register.php')) ?>" class="rounded-lg border-2 border-sabaw font-bold px-6 py-3 hover:bg-white transition-colors">
                    Gumawa ng account
                </a>
                <?php endif; ?>
            </div>
        </div>

        <!-- Sample day, shown as a receipt -->
        <div class="receipt rounded-lg p-6 max-w-sm w-full justify-self-center md:justify-self-end md:rotate-2" aria-label="Halimbawa ng gastos sa pagkain sa isang araw">
            <p class="font-display font-extrabold text-xl text-center">Kain Ngayong Araw</p>
            <p class="text-xs text-center text-sabaw-soft mb-4">Halimbawang presyo lang</p>
            <div class="space-y-3">
                <div class="receipt-row"><span>Sinangag at itlog</span><span class="dots"></span><span class="price">₱35</span></div>
                <div class="receipt-row"><span>Ginisang monggo</span><span class="dots"></span><span class="price">₱60</span></div>
                <div class="receipt-row"><span>Ginisang sardinas</span><span class="dots"></span><span class="price">₱45</span></div>
            </div>
            <div class="receipt-row mt-5 pt-3 border-t-2 border-dashed border-sabaw text-lg">
                <span class="font-bold">Buong araw</span><span class="dots"></span><span class="price text-atsuete text-2xl">₱140</span>
            </div>
        </div>
    </div>
</section>

<!-- Categories -->
<section id="kategorya" class="max-w-6xl mx-auto px-4 py-14 scroll-mt-16">
    <h2 class="font-display font-extrabold text-3xl sm:text-4xl">Ano ang lulutuin natin?</h2>
    <p class="mt-2 text-sabaw-soft max-w-xl">Pumili ng oras ng kain at tingnan ang mga ulam na pasok sa budget.</p>

    <div class="mt-8 grid gap-5 md:grid-cols-3">
        <?php foreach ($categories as $c): ?>
            <a href="<?= e($user ? url('dashboard.php?category=' . urlencode($c['name'])) : url('auth/login.php')) ?>"
               class="<?= $c['bg'] ?> <?= $c['text'] ?> rounded-2xl p-6 border-2 border-sabaw block hover:-translate-y-1 transition-transform">
                <span class="text-5xl" aria-hidden="true"><?= $c['emoji'] ?></span>
                <h3 class="font-display font-extrabold text-2xl mt-4"><?= e($c['name']) ?></h3>
                <p class="mt-2"><?= e($c['desc']) ?></p>
            </a>
        <?php endforeach; ?>
    </div>
</section>

<!-- Budget hacks -->
<section id="budget-hacks" class="bg-kalamansi-light border-y-2 border-sabaw/10 scroll-mt-16">
    <div class="max-w-6xl mx-auto px-4 py-14">
        <h2 class="font-display font-extrabold text-3xl sm:text-4xl">Budget Hacks</h2>
        <p class="mt-2 text-sabaw-soft max-w-xl">Maliit na pagbabago sa pamimili at pagluluto na malaki ang natitipid sa isang linggo.</p>

        <div class="mt-8 grid gap-8 lg:grid-cols-2">
            <div>
                <h3 class="font-display font-bold text-xl mb-3">Palit-sangkap mula sa sari-sari store</h3>
                <ul class="space-y-3">
                    <?php foreach ($swaps as [$from, $to]): ?>
                        <li class="bg-white rounded-lg border-2 border-sabaw/20 p-4">
                            <p class="text-sm text-sabaw-soft line-through"><?= e($from) ?></p>
                            <p class="font-medium"><?= e($to) ?></p>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div>
                <h3 class="font-display font-bold text-xl mb-3">Meal prep tips</h3>
                <ul class="space-y-3">
                    <?php foreach ($tips as $t): ?>
                        <li class="flex gap-3 bg-white rounded-lg border-2 border-sabaw/20 p-4">
                            <span class="mt-1 h-3 w-3 shrink-0 rounded-full bg-atsuete" aria-hidden="true"></span>
                            <span><?= e($t) ?></span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</section>

<!-- Closing call to action -->
<section class="max-w-6xl mx-auto px-4 py-14">
    <div class="bg-sabaw text-kalamansi-light rounded-2xl p-8 md:p-12 text-center">
        <h2 class="font-display font-extrabold text-3xl sm:text-4xl text-kalamansi">Simulan na ang sarili mong recipe book.</h2>
        <p class="mt-3 max-w-lg mx-auto">Isulat ang paborito mong ulam, ilagay ang budget at oras ng pagluluto, at balikan kahit kailan.</p>
        <a href="<?= e($ctaUrl) ?>" class="inline-block mt-6 rounded-lg bg-kalamansi text-sabaw font-bold px-6 py-3 hover:bg-atsuete hover:text-white transition-colors">
            <?= e($ctaText) ?>
        </a>
    </div>
</section>

<?php require __DIR__ . '/includes/footer.php'; ?>
