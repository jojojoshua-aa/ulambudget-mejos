<?php
require_once __DIR__ . '/../includes/functions.php';
$user = require_login();

$errors = [];
$values = ['dish_name' => '', 'category' => '', 'budget' => '', 'prep_time' => '', 'ingredients' => '', 'instructions' => ''];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $errors['form'] = 'Nag-expire ang form. Subukan ulit.';
        $values = array_merge($values, array_intersect_key($_POST, $values));
    } else {
        [$values, $errors] = validate_recipe($_POST);
        if (!$errors) {
            $stmt = db()->prepare(
                'INSERT INTO recipes (user_id, dish_name, category, budget, prep_time, ingredients, instructions, is_public)
                 VALUES (:uid, :name, :cat, :bud, :time, :ing, :ins, :pub)'
            );
            $stmt->execute([
                ':uid'  => $user['id'],
                ':name' => $values['dish_name'],
                ':cat'  => $values['category'],
                ':bud'  => $values['budget'],
                ':time' => (int) $values['prep_time'],
                ':ing'  => $values['ingredients'],
                ':ins'  => $values['instructions'],
                ':pub'  => is_admin() ? 1 : 0,   // admin recipes are shared with everyone
            ]);
            flash('success', 'Na-save ang recipe na "' . $values['dish_name'] . '".');
            redirect('recipes/view.php?id=' . (int) db()->lastInsertId());
        }
    }
}

$pageTitle   = 'Magdagdag ng Recipe';
$submitLabel = 'I-save ang recipe';
$cancelUrl   = url('dashboard.php');
require __DIR__ . '/../includes/header.php';
?>
<section class="max-w-3xl mx-auto px-4 py-8">
    <h1 class="font-display font-extrabold text-3xl">Magdagdag ng Recipe</h1>
    <p class="text-sabaw-soft mb-6">
        <?= is_admin() ? 'Makikita ng lahat ng user ang recipe na ito.' : 'Ikaw lang ang makakakita ng recipe na ito.' ?>
    </p>
    <?php if (!empty($errors['form'])): ?>
        <div role="alert" class="mb-4 rounded-lg bg-red-50 border-l-4 border-red-600 text-red-900 px-4 py-3"><?= e($errors['form']) ?></div>
        <?php unset($errors['form']); ?>
    <?php endif; ?>
    <?php require __DIR__ . '/../includes/recipe_form.php'; ?>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
