<?php
require_once __DIR__ . '/../includes/functions.php';
require_login();

// Delete only runs on a POST with a valid CSRF token (never from a plain link).
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !csrf_valid()) {
    flash('error', 'Hindi valid ang request. Subukan ulit.');
    redirect('dashboard.php');
}

$id     = (int) ($_POST['id'] ?? 0);
$recipe = $id > 0 ? find_recipe($id) : null;

if (!$recipe || !can_view_recipe($recipe)) {
    flash('error', 'Hindi nahanap ang recipe.');
    redirect('dashboard.php');
}
if (!can_manage_recipe($recipe)) {
    flash('error', 'Hindi mo pwedeng i-delete ang recipe ng ibang user.');
    redirect('dashboard.php');
}

$stmt = db()->prepare('DELETE FROM recipes WHERE id = :id');
$stmt->execute([':id' => $id]);

flash('success', 'Nabura na ang recipe na "' . $recipe['dish_name'] . '".');
redirect('dashboard.php');
