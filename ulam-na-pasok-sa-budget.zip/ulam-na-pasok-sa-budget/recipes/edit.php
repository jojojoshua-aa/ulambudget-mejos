<?php
require_once __DIR__ . '/../includes/functions.php';
$user = require_login();

$id     = (int) ($_GET['id'] ?? 0);
$recipe = $id > 0 ? find_recipe($id) : null;

if (!$recipe || !can_view_recipe($recipe)) {
    flash('error', 'Hindi nahanap ang recipe.');
    redirect('dashboard.php');
}
if (!can_manage_recipe($recipe)) {
    flash('error', 'Hindi mo pwedeng i-edit ang recipe ng ibang user.');
    redirect('recipes/view.php?id=' . $id);
}

$errors = [];
$values = [
    'dish_name'    => $recipe['dish_name'],
    'category'     => $recipe['category'],
    'budget'       => $recipe['budget'],
    'prep_time'    => (string) $recipe['prep_time'],
    'ingredients'  => $recipe['ingredients'],
    'instructions' => $recipe['instructions'],
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!csrf_valid()) {
        $errors['form'] = 'Nag-expire ang form. Subukan ulit.';
        $values = array_merge($values, array_intersect_key($_POST, $values));
    } else {
        [$values, $errors] = validate_recipe($_POST);
        if (!$errors) {
            $stmt = db()->prepare(
                'UPDATE recipes SET dish_name = :name, category = :cat, budget = :bud, prep_time = :time,
                        ingredients = :ing, instructions = :ins
                 WHERE id = :id'
            );
            $stmt->execute([
                ':name' => $values['dish_name'],
                ':cat'  => $values['category'],
                ':bud'  => $values['budget'],
                ':time' => (int) $values['prep_time'],
                ':ing'  => $values['ingredients'],
                ':ins'  => $values['instructions'],
                ':id'   => $id,
            ]);
            flash('success', 'Na-update ang recipe.');
            redirect('recipes/view.php?id=' . $id);
        }
    }
}

$pageTitle   = 'I-edit: ' . $recipe['dish_name'];
$submitLabel = 'I-save ang mga pagbabago';
$cancelUrl   = url('recipes/view.php?id=' . $id);
require __DIR__ . '/../includes/header.php';
?>
<section class="max-w-3xl mx-auto px-4 py-8">
    <h1 class="font-display font-extrabold text-3xl">I-edit ang Recipe</h1>
    <p class="text-sabaw-soft mb-6">May-akda: <?= e($recipe['author']) ?></p>
    <?php if (!empty($errors['form'])): ?>
        <div role="alert" class="mb-4 rounded-lg bg-red-50 border-l-4 border-red-600 text-red-900 px-4 py-3"><?= e($errors['form']) ?></div>
        <?php unset($errors['form']); ?>
    <?php endif; ?>
    <?php require __DIR__ . '/../includes/recipe_form.php'; ?>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
