<?php
require_once __DIR__ . '/../includes/functions.php';
$user = require_login();

$id     = (int) ($_GET['id'] ?? 0);
$recipe = $id > 0 ? find_recipe($id) : null;

if (!$recipe || !can_view_recipe($recipe)) {
    flash('error', 'Hindi nahanap ang recipe.');
    redirect('dashboard.php');
}

$st          = category_style($recipe['category']);
$ingredients = lines_to_array($recipe['ingredients']);
$steps       = lines_to_array($recipe['instructions']);

$pageTitle = $recipe['dish_name'];
require __DIR__ . '/../includes/header.php';
?>
<section class="max-w-3xl mx-auto px-4 py-8">
    <a href="<?= e(url('dashboard.php')) ?>" class="text-sm font-bold underline">&larr; Bumalik sa mga recipe</a>

    <article class="mt-4 bg-white border-2 border-sabaw rounded-xl overflow-hidden shadow-[6px_6px_0_#3A1F0F]">
        <header class="<?= $st['badge'] ?> p-6">
            <p class="font-bold"><?= $st['emoji'] ?> <?= e($recipe['category']) ?><?= (int) $recipe['is_public'] === 0 ? ' (Pribado)' : '' ?></p>
            <h1 class="font-display font-extrabold text-3xl sm:text-4xl mt-1 leading-tight"><?= e($recipe['dish_name']) ?></h1>
        </header>

        <div class="p-6">
            <dl class="grid grid-cols-3 gap-4 text-center border-b-2 border-dashed border-sabaw/30 pb-5">
                <div><dt class="text-sm text-sabaw-soft">Budget</dt><dd class="font-display font-extrabold text-lg text-atsuete"><?= e($recipe['budget']) ?></dd></div>
                <div><dt class="text-sm text-sabaw-soft">Paghahanda</dt><dd class="font-display font-extrabold text-lg"><?= (int) $recipe['prep_time'] ?> min</dd></div>
                <div><dt class="text-sm text-sabaw-soft">May-akda</dt><dd class="font-bold"><?= e($recipe['author']) ?></dd></div>
            </dl>

            <h2 class="font-display font-bold text-xl mt-6 mb-2">Mga sangkap</h2>
            <ul class="list-disc ml-6 space-y-1">
                <?php foreach ($ingredients as $item): ?><li><?= e($item) ?></li><?php endforeach; ?>
            </ul>

            <h2 class="font-display font-bold text-xl mt-6 mb-2">Paraan ng pagluluto</h2>
            <ol class="list-decimal ml-6 space-y-2">
                <?php foreach ($steps as $step): ?><li><?= e($step) ?></li><?php endforeach; ?>
            </ol>

            <?php if (can_manage_recipe($recipe)): ?>
            <div class="mt-8 pt-5 border-t-2 border-sabaw/10 flex flex-wrap gap-3">
                <a href="<?= e(url('recipes/edit.php?id=' . $id)) ?>" class="rounded-lg bg-atsuete hover:bg-atsuete-dark text-white font-bold px-5 py-2.5">I-edit</a>
                <form method="post" action="<?= e(url('recipes/delete.php')) ?>"
                      data-confirm="Sigurado ka bang buburahin ang &quot;<?= e($recipe['dish_name']) ?>&quot;? Hindi na ito maibabalik.">
                    <?= csrf_field() ?>
                    <input type="hidden" name="id" value="<?= $id ?>">
                    <button type="submit" class="rounded-lg bg-red-600 hover:bg-red-700 text-white font-bold px-5 py-2.5">I-delete</button>
                </form>
            </div>
            <?php endif; ?>
        </div>
    </article>
</section>
<?php require __DIR__ . '/../includes/footer.php'; ?>
